#!/bin/bash
echo "Checking for existing debug pods"
/root/Testing-k8s/Check-for-no-debug-pods-in-testing-NS.sh 
echo "creating a debug pod using test image. no service. no ingress"
/root/Testing-k8s/Create-Debug-tool-in-testing-NS.sh 
echo "scale up to four pods"
/root/Testing-k8s/Scale-Debug-tool-in-testing-NS.sh
echo "waiting for the debug pods to be ready"
/root/Testing-k8s/Wait-For-Debug-Pods-in-testing-NS.sh 
echo "install hooks in contrail-api so we can enable snat on the test network"
kubectl cp /root/Testing-k8s/snat-on.py $(kubectl get pods -n kube-system --no-headers=true | awk '/contrail-controller-config/{print $1}'):/tmp/snat-on.py -n kube-system -c contrail-controller-config-api
kubectl cp /root/Testing-k8s/snat-off.py $(kubectl get pods -n kube-system --no-headers=true | awk '/contrail-controller-config/{print $1}'):/tmp/snat-off.py -n kube-system -c contrail-controller-config-api
kubectl exec -it $(kubectl get pods -n kube-system --no-headers=true | awk '/contrail-controller-config/{print $1}') -n kube-system -c contrail-controller-config-api /usr/bin/python /tmp/snat-on.py
echo "testing each debug pod for connectivity to its vrouter gateway ip"
/root/Testing-k8s/Test-Debug-tool-in-testing-NS-Gateway.sh
echo "testing each debug pod for dns and for connectivity out to internet"
/root/Testing-k8s/Test-Debug-tool-in-testing-NS-Google.sh
echo "Cleaning up"
/root/Testing-k8s/Delete-Debug-tool-in-testing-NS.sh
