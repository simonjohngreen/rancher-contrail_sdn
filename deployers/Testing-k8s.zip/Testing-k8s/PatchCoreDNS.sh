#!/bin/bash
#patch to remove liveness and readiness probes in coredns as ip fabric forwarding a) breaks federation b) doesn't allow snat which we need
kubectl get deployments -n kube-system -o name |grep 'coredns' |xargs -I replaceme kubectl patch replaceme -n kube-system  --type=json -p='[{"op": "remove", "path": "/spec/template/spec/containers/0/livenessProbe"}]'
kubectl get deployments -n kube-system -o name |grep 'coredns' |xargs -I replaceme kubectl patch replaceme -n kube-system  --type=json -p='[{"op": "remove", "path": "/spec/template/spec/containers/0/readinessProbe"}]'
kubectl get pods -n kube-system -oname |grep coredns |xargs kubectl delete -n kube-system
