import socket
from vnc_api import vnc_api
vnc = vnc_api.VncApi(api_server_host=socket.gethostname())
gsc_uuid = vnc.global_system_configs_list()['global-system-configs'][0]['uuid']
gsc = vnc.global_system_config_read(id=gsc_uuid)
gsc.set_enable_4byte_as(True)
vnc.global_system_config_update(gsc)
