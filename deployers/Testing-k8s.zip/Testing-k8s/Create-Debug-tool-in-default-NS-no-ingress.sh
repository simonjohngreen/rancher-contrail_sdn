#!/bin/bash
kubectl apply -f /root/Testing-k8s/debug-default-NS-deployment.yaml
