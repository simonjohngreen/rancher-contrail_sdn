#!/bin/bash
kubectl apply -f /root/Testing-k8s/testing-NS-Create.yaml
kubectl apply -f /root/Testing-k8s/debug-testing-NS-deployment.yaml
