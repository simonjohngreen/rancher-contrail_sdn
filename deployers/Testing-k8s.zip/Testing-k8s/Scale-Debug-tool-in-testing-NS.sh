#!/bin/bash
kubectl scale deployment.v1.apps/debug-default -n testing --replicas=4
