#!/bin/bash
for  i in `kubectl get pods -n testing --no-headers=true | awk '/debug/{print $1}'`
do
	echo "**************" 
	echo pod is $i
        echo worker is $(kubectl get pod $i -o wide -n testing | sed -n 2p | tr -s ' ' | cut -d" " -f 7)
	echo "**************" 
	kubectl  exec $i -n testing -- ping -i 0.3 -c 4 8.8.8.8 
done
