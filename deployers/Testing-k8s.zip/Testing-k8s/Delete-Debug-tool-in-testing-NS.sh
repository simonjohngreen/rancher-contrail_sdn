#!/bin/bash
kubectl delete deployment debug-default -n testing
kubectl delete -f /root/Testing-k8s/debug-testing-NS-service.yaml
kubectl delete -f /root/Testing-k8s/debug-testing-NS-ingress.yaml
kubectl delete -f /root/Testing-k8s/testing-NS-Create.yaml
