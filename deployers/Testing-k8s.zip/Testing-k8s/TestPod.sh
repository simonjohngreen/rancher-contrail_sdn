#!/bin/bash
/root/Testing-k8s/Create-Debug-tool-in-default-NS-no-ingress.sh 
/root/Testing-k8s/Create-Debug-tool-in-testing-NS-no-ingress.sh 
kubectl cp /root/Testing-k8s/snat-on.py $(kubectl get pods -n kube-system --no-headers=true | awk '/contrail-controller-config/{print $1}'):/tmp/snat-on.py -n kube-system -c contrail-controller-config-api
kubectl exec -it $(kubectl get pods -n kube-system --no-headers=true | awk '/contrail-controller-config/{print $1}') -n kube-system -c contrail-controller-config-api /usr/bin/python /tmp/snat-on.py
