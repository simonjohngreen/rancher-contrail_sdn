#!/bin/bash
if [ $# -ne 1 ]; then
   echo "needs one parameter [tennant name]"
   echo "For example: /root/Testing-k8s/Show.sh deposits"
   echo "For example: /root/Testing-k8s/Show.sh mortgages"
   echo "For example: /root/Testing-k8s/Show.sh all"
   exit 1
fi

if [ $1 == "all" ]; then
     echo "****Namespaces***"
     kubectl get namespaces
     echo "****NetworkPolicy***"
     kubectl get networkpolicy 
     echo "****Pods***"
     kubectl get pods --all-namespaces -o wide  | grep -v kube-system  
     kubectl get pods --all-namespaces  | grep -v kube-system  
     echo "****Deployments***"
     kubectl get deployments --all-namespaces 
     echo "****Services***"
     kubectl get services --all-namespaces 
     echo "****Ingress***"
     kubectl get ingress --all-namespaces 
else
     echo "****Namespaces***"
     kubectl get namespaces
     echo "****Pods***"
     kubectl get pods -o wide --namespace=$1 
     echo "****Deployments***"
     kubectl get deployments --namespace=$1 
     echo "****Services***"
     kubectl get services --namespace=$1 
     echo "****Ingress***"
     kubectl get ingress --namespace=$1 
fi

