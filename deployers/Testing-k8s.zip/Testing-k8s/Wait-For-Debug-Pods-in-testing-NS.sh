#!/bin/bash
for  i in `kubectl get pods --no-headers=true -n testing | awk '/debug/{print $1}'` 
do
	echo checking that pod $i  is ready
	while [[ $(kubectl get pod $i -n testing -o 'jsonpath={..status.conditions[?(@.type=="Ready")].status}') != "True" ]];
	do
   		echo "waiting for pod $i" && sleep 1;
	done
done

