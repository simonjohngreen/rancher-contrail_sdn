#!/bin/bash
kubectl adm policy add-scc-to-user anyuid -z default --namespace=testing
kubectl apply -f /root/Testing-k8s/testing-NS-Create.yaml
kubectl apply -f /root/Testing-k8s/debug-testing-NS-deployment.yaml
kubectl apply -f /root/Testing-k8s/debug-testing-NS-service.yaml
kubectl apply -f /root/Testing-k8s/debug-testing-NS-ingress.yaml
