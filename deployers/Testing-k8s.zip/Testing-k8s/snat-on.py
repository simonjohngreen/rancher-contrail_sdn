import socket
from vnc_api import vnc_api
vnc_lib = vnc_api.VncApi(api_server_host=socket.gethostname())
vn_network_obj=vnc_lib.virtual_network_read(fq_name = ['default-domain', 'k8s-testing', 'k8s-testing-pod-network'])
vnc_lib.virtual_network_update(vn_network_obj)
vn_network_obj.set_fabric_snat(True)
vnc_lib.virtual_network_update(vn_network_obj)
