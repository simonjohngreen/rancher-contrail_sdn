#!/bin/bash
for  i in `kubectl get pods --no-headers=true -n Debug | awk '/debug/{print $1}'` 
do
	while [[ $(kubectl get pods -n Debug | grep debug-default | wc -l) != "0" ]];
	do
   		echo "I see existing debug-default pods in the Debug NS, waiting for them to be deleted" && sleep 1;
	done
done
